package www.beijia.com.cn.dozip;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Administrator on 2020-2-17.
 */

public class PetBean implements Parcelable {

    /**
     * id : 1
     * zip : https://cdn.dreamcapsule.top/%E6%81%B6%E9%BE%99.zip
     * name : 恶龙1
     * image : https://cdn.dreamcapsule.top/1560320751496870.jpg
     * useCount : 12200
     * likeCount : 23330
     */

    public int id;
    public String zip;
    public String name;
    public String image;
    public int useCount;
    public int likeCount;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.zip);
        dest.writeString(this.name);
        dest.writeString(this.image);
        dest.writeInt(this.useCount);
        dest.writeInt(this.likeCount);
    }

    public PetBean() {
    }

    protected PetBean(Parcel in) {
        this.id = in.readInt();
        this.zip = in.readString();
        this.name = in.readString();
        this.image = in.readString();
        this.useCount = in.readInt();
        this.likeCount = in.readInt();
    }

    public static final Creator<PetBean> CREATOR = new Creator<PetBean>() {
        @Override
        public PetBean createFromParcel(Parcel source) {
            return new PetBean(source);
        }

        @Override
        public PetBean[] newArray(int size) {
            return new PetBean[size];
        }
    };
}
