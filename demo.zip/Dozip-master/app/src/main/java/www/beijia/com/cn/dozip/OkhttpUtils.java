package www.beijia.com.cn.dozip;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class OkhttpUtils {
    private static String TAG = OkhttpUtils.class.getSimpleName();
    private static final BlockingQueue<Runnable> POOL_QUEUE_TASK = new SynchronousQueue<Runnable>();
    private static final ThreadFactory TASK_FACTORY = new ThreadFactory() {
        private final AtomicInteger COUNT = new AtomicInteger(1);

        public Thread newThread(Runnable runnable) {
            int count = COUNT.getAndIncrement();
            return new Thread(runnable, "Func #" + count);
        }
    };
    /**
     * 线程池
     */
    public static final ExecutorService FUNC_TASK = new ThreadPoolExecutor(8,
            Integer.MAX_VALUE, 3L, TimeUnit.SECONDS, POOL_QUEUE_TASK,
            TASK_FACTORY);

    /**
     * get请求
     *
     * @param url
     */
    public static Call getCall(String url) {
        // TODO Auto-generated method stub
        Log.i(TAG, "get请求url:" + url);
        OkHttpClient client = new OkHttpClient.Builder()
                .writeTimeout(20, TimeUnit.SECONDS)
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS).build();

        Request request = new Request.Builder().url(url).get().build();
        Call call = client.newCall(request);
        return call;
    }

    /**
     * get请求
     *
     * @param url
     */
    public static Call postCall(String url, String json) {
        // TODO Auto-generated method stub
        Log.i(TAG, "get请求url:" + url);
        OkHttpClient client = new OkHttpClient.Builder()
                .writeTimeout(20, TimeUnit.SECONDS)
                .connectTimeout(20, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS).build();

        MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder().url(url).post(body).build();
        Call call = client.newCall(request);
        return call;
    }

    /**
     * Response 转 String
     *
     * @param response
     * @return
     * @throws IOException
     */
    public static String ResponseToString(Response response) throws IOException {
        if (response.isSuccessful()) {
            byte[] buffer = new byte[1024];
            BufferedInputStream bis = new BufferedInputStream(response.body()
                    .byteStream());
            int read = bis.read(buffer);

            byte[] mByte = new byte[1024 * 10];
            int index = 0;
            while (read > 0) {
                System.arraycopy(buffer, 0, mByte, index, read);
                index = index + read;
                read = bis.read(buffer);
            }

            String mRes = "";
            byte[] resp = new byte[index];
            if (0 < mByte.length) {
                System.arraycopy(mByte, 0, resp, 0, index);
                mRes = new String(resp);
            } else {
                mRes = "";
            }
            Log.i(TAG, "get请求成功: " + mRes);
            return mRes;
        } else {
            Log.i(TAG, "get请求异常: " + response);
            return "";
        }
    }
}
