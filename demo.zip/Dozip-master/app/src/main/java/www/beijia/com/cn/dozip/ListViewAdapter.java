package www.beijia.com.cn.dozip;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;

/**
 * GridView适配器
 *
 * @author zihao
 */
public class ListViewAdapter extends BaseAdapter {

    private LayoutInflater inflater;
    private PetsBean bean;

    public ListViewAdapter(Context context, PetsBean mBean) {
        inflater = LayoutInflater.from(context);
        bean = mBean;
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return bean.petList.size() > 0 ? bean.petList.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return bean.petList.size() > 0 ? bean.petList.get(position) : "";
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        ViewHolder holder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.view_list, null);
            holder = new ViewHolder();
            holder.titleName = (TextView) convertView.findViewById(R.id.view_list_tv);
            holder.imgView = (ImageView) convertView.findViewById(R.id.view_list_img);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.titleName.setText(bean.petList.get(position).name);
        ImageLoader.getInstance().displayImage(bean.petList.get(position).image, holder.imgView);
        return convertView;
    }

    /**
     * 工具类
     */
    private class ViewHolder {
        TextView titleName = null;
        ImageView imgView;
    }

}
