package www.beijia.com.cn.dozip;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

/**
 * Created by Administrator on 2020-2-17.
 */

public class PetsBean implements Parcelable {

    public List<PetListBean> petList;


    public static class PetListBean implements Parcelable {
        /**
         * id : 1
         * name : 恶龙1
         * image : https://cdn.dreamcapsule.top/1560320751496870.jpg
         */

        public int id;
        public String name;
        public String image;


        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(this.id);
            dest.writeString(this.name);
            dest.writeString(this.image);
        }

        public PetListBean() {
        }

        protected PetListBean(Parcel in) {
            this.id = in.readInt();
            this.name = in.readString();
            this.image = in.readString();
        }

        public static final Creator<PetListBean> CREATOR = new Creator<PetListBean>() {
            @Override
            public PetListBean createFromParcel(Parcel source) {
                return new PetListBean(source);
            }

            @Override
            public PetListBean[] newArray(int size) {
                return new PetListBean[size];
            }
        };
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(this.petList);
    }

    public PetsBean() {
    }

    protected PetsBean(Parcel in) {
        this.petList = in.createTypedArrayList(PetListBean.CREATOR);
    }

    public static final Creator<PetsBean> CREATOR = new Creator<PetsBean>() {
        @Override
        public PetsBean createFromParcel(Parcel source) {
            return new PetsBean(source);
        }

        @Override
        public PetsBean[] newArray(int size) {
            return new PetsBean[size];
        }
    };
}
