package www.beijia.com.cn.dozip;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import com.nostra13.universalimageloader.core.ImageLoader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

/**
 * Created by Administrator on 2020-2-17.
 */


public class ListViewActivity extends Activity implements AdapterView.OnItemClickListener {
    private static final String TAG = ListViewActivity.class.getSimpleName();
    private RelativeLayout petView;
    private ListView mListView;
    private static final String petsUrl = "https://petdemoserver.now.sh/pets";
    private static final String petUrl = "https://petdemoserver.now.sh/pet/";
    private String PATH = "";
    private PetsBean bean;
    private PetBean mPetBean;
    private static ProgressDialog mDialog;
    private TextView titleName, count;
    private ImageView imgView, img_animation, animationImg;
    private File[] files;
    private boolean isRun = false;
    private int i = 0;

    private WindowManager mWindowManager;

    public ZipExtractorTask.ZipOverListener mZipOverListener = new ZipExtractorTask.ZipOverListener() {
        @Override
        public void zipOver() {
            File file = new File(PATH + "img/");
            if (!file.isDirectory()) {
                Log.i(TAG, "数据解压失败");
                Toast.makeText(ListViewActivity.this, "数据解压失败", Toast.LENGTH_LONG).show();
                return;
            }
            files = file.listFiles();
            ImgAnimation();
        }
    };

    public void ImgAnimation() {
        animationImg.setVisibility(View.VISIBLE);
        i = 0;
        if (isRun) {
            return;
        }
        isRun = true;
        OkhttpUtils.FUNC_TASK.execute(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    Log.i(TAG, "循环" + i);
                    handler.sendEmptyMessage(i);
                    i++;
                    if (i == files.length) {
                        i = 0;
                    }
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }


    public LayoutParams getLayoutParams() {
        LayoutParams param = new LayoutParams();
        param = new LayoutParams();
        param.type = LayoutParams.TYPE_SYSTEM_ERROR; // 系统提示类型,重要
        param.format = PixelFormat.RGBA_8888;

        param.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
                | LayoutParams.FLAG_NOT_FOCUSABLE
                | LayoutParams.FLAG_FULLSCREEN
                | LayoutParams.FLAG_LAYOUT_IN_SCREEN;

        param.gravity = Gravity.CENTER | Gravity.TOP;
        param.x = 0;
        param.y = 0;
        param.width = LayoutParams.MATCH_PARENT;
        param.height = LayoutParams.MATCH_PARENT;
        return param;
    }


    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            File f = files[msg.what];
            if (f.getName().endsWith(".png") || f.getName().endsWith(".PNG") || f.getName().endsWith(".jpg") || f.getName().endsWith(".JPG")) {
                Uri contentUri;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    contentUri = FileProvider.getUriForFile(ListViewActivity.this, "www.beijia.com.cn.dozip", f);
                } else {
                    contentUri = Uri.fromFile(f);
                }

                if (f.exists()) {
//                    ImageLoader.getInstance().displayImage(String.valueOf(contentUri), img_animation);
//                    img_animation.setImageURI(contentUri);
                    animationImg.setImageURI(contentUri);
                }
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);
        mListView = findViewById(R.id.list_view);
        mListView.setOnItemClickListener(this);

        petView = findViewById(R.id.view_pet);
        titleName = findViewById(R.id.view_pet_title);
        count = findViewById(R.id.view_pet_count);
        imgView = findViewById(R.id.view_pet_img);

        //程序内动画
        img_animation = findViewById(R.id.img_animation);

        //窗口动画
        mWindowManager = (WindowManager) this.getSystemService(Context.WINDOW_SERVICE);
        animationImg = new ImageView(ListViewActivity.this);
        animationImg.setVisibility(View.INVISIBLE);
        animationImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i(TAG, "窗口动画---------");
                animationImg.setVisibility(View.INVISIBLE);
            }
        });

        ImageLoader.getInstance().displayImage("https://cdn.dreamcapsule.top/1560320751496870.jpg", animationImg);
        mWindowManager.addView(animationImg, getLayoutParams());

        PATH = Environment.getExternalStorageDirectory() + "/" + getApplication().getPackageName() + "/";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(ListViewActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    || ContextCompat.checkSelfPermission(ListViewActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                    || ContextCompat.checkSelfPermission(ListViewActivity.this, Manifest.permission.MOUNT_UNMOUNT_FILESYSTEMS) != PackageManager.PERMISSION_GRANTED
                    || ContextCompat.checkSelfPermission(ListViewActivity.this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(ListViewActivity.this, new String[]{Manifest.permission.RECORD_AUDIO
                        , Manifest.permission.WRITE_EXTERNAL_STORAGE
                        , Manifest.permission.READ_EXTERNAL_STORAGE
                        , Manifest.permission.MOUNT_UNMOUNT_FILESYSTEMS
                        , Manifest.permission.INTERNET}, 101);
                Toast.makeText(this, "申请权限", Toast.LENGTH_LONG).show();
            }
        }
        getResponse(petsUrl);
    }


    /**
     * 请求列表数据
     */
    public void getResponse(final String path) {
        Dialog();

        OkhttpUtils.FUNC_TASK.execute(new Runnable() {
            @Override
            public void run() {
                OkhttpUtils.getCall(path).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        Log.i(TAG, "请求列表数据错误");
                        if (mDialog != null) {
                            mDialog.dismiss();
                        }
                        getResponse(path);
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        try {
                            if (petsUrl.equals(path)) {
                                String pets = "{petList:" + OkhttpUtils.ResponseToString(response) + "}";
                                Log.i(TAG, "onResponse: " + pets);
                                bean = new Gson().fromJson(pets, PetsBean.class);
                                setAdapter();
                            } else {
                                mPetBean = new Gson().fromJson(OkhttpUtils.ResponseToString(response), PetBean.class);
                                setPetInfo();
                            }
                            if (mDialog != null) {
                                mDialog.dismiss();
                            }
                        } catch (JsonIOException e) {
                            // TODO: handle exception
                            e.printStackTrace();
                        } catch (JsonSyntaxException e) {
                            // TODO: handle exception
                            e.printStackTrace();
                        } catch (JsonParseException e) {
                            // TODO: handle exception
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
    }


    /**
     * 设置列表
     */
    public void setAdapter() {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ListViewAdapter adapter = new ListViewAdapter(ListViewActivity.this, bean);
                mListView.setAdapter(adapter);
            }
        });
    }

    /**
     * 监听点击
     *
     * @param adapterView
     * @param view
     * @param i
     * @param l
     */
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        petView.setVisibility(View.VISIBLE);
        getResponse(petUrl + bean.petList.get(i).id);
        deleteFile(new File(PATH));
    }

    /**
     * 删除缓存文件
     */

    /**
     * 递归删除 文件/文件夹
     *
     * @param file
     */
    public void deleteFile(File file) {
        Log.i(TAG, "delete file path=" + file.getAbsolutePath());
        if (file.exists()) {
            if (file.isFile()) {
                file.delete();
            } else if (file.isDirectory()) {
                File files[] = file.listFiles();
                for (int i = 0; i < files.length; i++) {
                    deleteFile(files[i]);
                }
            }
            file.delete();
        } else {
            Log.e(TAG, "delete file no exists " + file.getAbsolutePath());
        }
    }

    /**
     * 设置详情
     */
    public void setPetInfo() {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                titleName.setText(mPetBean.name);
                count.setText("使用次数：" + mPetBean.useCount + " 喜欢次数" + mPetBean.likeCount);
                ImageLoader.getInstance().displayImage(mPetBean.image, imgView);

                showDownLoadDialog();
            }
        });
    }


    private void showDownLoadDialog() {
        new AlertDialog.Builder(this).setTitle("提示")
                .setMessage("是否下载显示动画？")
                .setPositiveButton("是", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub
                        Log.d(TAG, "onClick 1 = " + which);
                        DownLoaderTask task = new DownLoaderTask(mPetBean.zip, PATH, ListViewActivity.this, mZipOverListener, true);
                        task.execute();
                    }
                })
                .setNegativeButton("否", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub
                        Log.d(TAG, "onClick 2 = " + which);
                    }
                }).show();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if (KeyEvent.KEYCODE_BACK == event.getKeyCode()) {
            Log.i(TAG, "按返回");
            if (petView.getVisibility() == View.VISIBLE) {
                petView.setVisibility(View.INVISIBLE);
                return true;
            }
            if (animationImg.getVisibility() == View.VISIBLE) {
                animationImg.setVisibility(View.INVISIBLE);
                return true;
            }
//            if (mWindowManager != null) {
//                mWindowManager.removeView(animationImg);
//            }
        }
        return super.onKeyDown(keyCode, event);
    }

    public void Dialog() {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mDialog = new ProgressDialog(ListViewActivity.this);
                mDialog.setTitle("正在加载，请稍候...");
                mDialog.setMessage("");
                mDialog.setMax(100);
                mDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mDialog.show();
            }
        });
    }
}
